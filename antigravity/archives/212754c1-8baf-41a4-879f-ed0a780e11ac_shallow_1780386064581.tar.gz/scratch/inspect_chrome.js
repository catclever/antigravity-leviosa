const WebSocket = require('ws');

const wsUrl = "ws://localhost:9222/devtools/page/81C0111FFA5AD3FFBFCCF48B4AC2D83D";
const ws = new WebSocket(wsUrl);

let id = 1;

ws.on('open', () => {
    const script = `
        const headerText = Array.from(document.querySelectorAll('.text-text-secondary')).map(el => el.innerText).filter(t => t && t.includes('Highlight '));
        const highlightedLines = Array.from(document.querySelectorAll('span')).filter(s => s.style.backgroundColor && s.style.backgroundColor !== 'transparent').map(s => s.innerText);
        
        ({
            headers: headerText,
            highlightCount: highlightedLines.length,
            highlightedLines: highlightedLines.slice(0, 5)
        });
    `;
    
    ws.send(JSON.stringify({
        id: id++,
        method: "Runtime.evaluate",
        params: {
            expression: script,
            returnByValue: true
        }
    }));
});

ws.on('message', (data) => {
    const msg = JSON.parse(data);
    if (msg.id === 1) {
        console.log("Wiki Info:", JSON.stringify(msg.result, null, 2));
        ws.close();
    }
});
