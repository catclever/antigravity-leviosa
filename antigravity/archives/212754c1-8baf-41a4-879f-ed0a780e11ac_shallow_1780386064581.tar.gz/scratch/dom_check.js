const WebSocket = require('ws');

const wsUrl = "ws://localhost:9222/devtools/page/81C0111FFA5AD3FFBFCCF48B4AC2D83D";
const ws = new WebSocket(wsUrl);

let id = 1;

ws.on('open', () => {
    const script = `
        const headerText = Array.from(document.querySelectorAll('.text-text-secondary')).map(el => el.innerText).filter(t => t && t.includes('Highlight '));
        const highlightedLines = Array.from(document.querySelectorAll('span')).filter(s => s.style.backgroundColor && s.style.backgroundColor !== 'transparent').map(s => s.innerText);
        const codeWrappers = document.querySelectorAll('code > span');
        const first10WrapperClasses = Array.from(codeWrappers).slice(0, 10).map(s => s.className);
        
        ({
            headers: headerText,
            highlightCount: highlightedLines.length,
            highlightedLines: highlightedLines,
            wrapperClasses: first10WrapperClasses
        });
    `;
    
    ws.send(JSON.stringify({
        id: id++,
        method: "Runtime.evaluate",
        params: {
            expression: script,
            returnByValue: true
        }
    }));
});

ws.on('message', (data) => {
    const msg = JSON.parse(data);
    if (msg.id === 1) {
        console.log("DOM Info:", JSON.stringify(msg.result.value, null, 2));
        ws.close();
    }
});
