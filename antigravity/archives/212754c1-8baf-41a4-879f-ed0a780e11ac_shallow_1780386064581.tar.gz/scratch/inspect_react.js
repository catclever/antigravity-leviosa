const puppeteer = require('puppeteer-core');

(async () => {
  try {
    const browser = await puppeteer.connect({
      browserWSEndpoint: 'ws://localhost:9222/devtools/browser/93a50ef0-9d83-45c2-a596-eddb3306d0f8',
      defaultViewport: null
    });
    const targets = browser.targets();
    const target = targets.find(t => t.url().includes('localhost:4173') && t.url().includes('wikiPage'));
    const page = await target.page();
    
    const data = await page.evaluate(() => {
      // Find all elements containing 227 or 255
      const elements = Array.from(document.querySelectorAll('*'))
        .filter(el => el.children.length === 0 && (el.textContent.includes('227') || el.textContent.includes('255')))
        .map(el => el.outerHTML);
        
      return elements;
    });
    console.log(JSON.stringify(data, null, 2));
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
})();
