(async () => {
  try {
    const res = await fetch('http://localhost:9222/json');
    const data = await res.json();
    const page = data.find(p => p.url.includes('wikiPage') && p.url.includes('localhost:4173'));
    if (!page) {
        console.log("Not found");
        return;
    }
    console.log(page.webSocketDebuggerUrl);
  } catch(e) {
    console.error("Fetch failed", e.message);
  }
})();
